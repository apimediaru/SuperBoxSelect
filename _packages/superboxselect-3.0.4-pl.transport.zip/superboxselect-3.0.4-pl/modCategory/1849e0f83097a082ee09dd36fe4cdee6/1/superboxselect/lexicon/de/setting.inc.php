<?php
/**
 * Setting Lexicon Entries for SuperBoxSelect
 *
 * @package superboxselect
 * @subpackage lexicon
 */
$_lang['setting_superboxselect.advanced'] = 'Erweitert';
$_lang['setting_superboxselect.advanced_desc'] = 'Erweiterte TV-Einstellungen anzeigen (z.B. Feld Template).';
$_lang['setting_superboxselect.debug'] = 'Debug';
$_lang['setting_superboxselect.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
