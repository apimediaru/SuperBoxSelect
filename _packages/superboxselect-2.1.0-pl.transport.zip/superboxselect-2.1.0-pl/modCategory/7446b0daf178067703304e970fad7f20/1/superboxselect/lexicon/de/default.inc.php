<?php
$_lang['superboxselect'] = 'SuperBoxSelect';

$_lang['superboxselect.maxResources'] = 'Max. Ressourcen';
$_lang['superboxselect.maxResources_desc'] = 'Maximale Anzahl von Ressourcen (0 bedeutet keine Einschränkung)';
$_lang['superboxselect.maxResources_label'] = 'max. {maxResources}';
$_lang['superboxselect.maxResources_msg'] = 'Maximale Anzahl von Ressourcen erreicht.';
$_lang['superboxselect.pageSize'] = 'Seitengröße';
$_lang['superboxselect.pageSize_desc'] = 'Wenn die Seitengröße größer als 0 ist, wird eine Paginierung in der Fußzeile der Dropdown-Liste angezeigt.';
